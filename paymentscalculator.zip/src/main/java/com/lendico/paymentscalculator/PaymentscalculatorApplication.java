package com.lendico.paymentscalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentscalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentscalculatorApplication.class, args);
	}

}
